# Zion | Side-passage gate test 01
Computational screening of two equal, side-by-side stadium loops. No physical tank trial or fish observations. Each case starts with its gate at a fixed opening. Gate-motion transients are outside this test.

## Method
Each loop has centerline radius 1, straight length 3.5 and channel width 0.5 in normalized units. The inner straights face each other across a 0.3 gap. The transfer passage joins their midpoints. The maximum opening width is 1. A uniform tangential drive acts inside both rings. Edge flow equals the mean local driving component plus a pressure correction enforcing zero net flux in every wet cell. Walls have no through-flow. This linear-resistance approximation omits inertia, turbulent and molecular mixing, vertical variation and the actual inlet/pump layout.

For every geometry, start the lower half uniformly dyed and the upper half clear. Transport dye conservatively with first-order upwinding for 12 normalized time units. Relative rotation +1 gives opposing currents along the facing straights, while -1 gives aligned currents. Outer flux is the magnitude crossing the midpoint of each outer straight. One-way gate flux measures flow crossing the passage centerline in the positive y direction. Equal counterflow can give zero net volume transfer while moving dye.

## Interpretation
Bulk circulation persisted across the tested openings. Calculated dye exchange was strongly mesh-dependent. The symmetric aligned-current case can yield zero exchange under these equations. The results support measuring the passage directly. They cannot establish an exchange rate, jet severity, local slow pockets, schooling response or welfare.

## Reproduce
Run python test_gate.py in a writable directory with NumPy and SciPy installed. This regenerates results.csv. Each run checks cell flux balance, conservation of total dye, and concentration bounds. All cases are deterministic. The CSV records every resolution and both loop measurements.

## Recorded result
18 cases completed. With opposing currents and the full opening, dye recovered in the receiving loop was 1.1401%, 0.5446%, and 0.2620% on successively finer grids. Closed controls gave zero. On the finest grid the half opening gave 0.0924%. On that grid both loops' outer-straight flows changed by under 0.02% relative to their closed controls. Exchange magnitude is unresolved. Physical follow-up should measure local velocities on both sides of the passage during gate movement, downstream dye recovery and outer-straight flow at the same pump settings.
