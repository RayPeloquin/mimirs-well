"""Dimensionless depth-averaged linear resistance network. Run with Python, NumPy and SciPy."""
import csv
import numpy as np
from scipy.sparse import coo_matrix, diags
from scipy.sparse.csgraph import connected_components
from scipy.sparse.linalg import spsolve

def simulate(h, opening, direction):
    # Stadium-shaped channels, horizontal straights with semicircular ends.
    x,y=np.meshgrid(np.arange(-4+h/2,4,h),np.arange(-3+h/2,3,h))
    offset=y-np.where(y>0,1.4,-1.4)
    dx=x-np.clip(x,-1.75,1.75)
    radius=np.hypot(dx,offset)
    ring=(radius>.75)&(radius<1.25)
    wet=ring|((abs(x)<opening/2)&(abs(y)<.5))
    ids=np.full(wet.shape,-1)
    ids[wet]=np.arange(wet.sum())
    a,b,drive=[],[],[]
    for axis,component in [(1,-offset),(0,dx)]:
        neighbor=np.roll(ids,-1,axis)
        edge=wet&(neighbor>=0)
        force=component/np.maximum(radius,1e-12)*ring*np.where(y>0,1,direction)
        a.extend(ids[edge]); b.extend(neighbor[edge])
        drive.extend(((force+np.roll(force,-1,axis))/2)[edge])
    a,b,drive=map(np.asarray,(a,b,drive))
    edges=np.arange(len(a))
    D=coo_matrix((np.r_[np.ones(len(a)),-np.ones(len(a))],
                  (np.r_[a,b],np.r_[edges,edges])),shape=(wet.sum(),len(a))).tocsr()
    L=D@D.T
    _,labels=connected_components(L,directed=False)
    pins=np.zeros(wet.sum()); pins[np.unique(labels,return_index=True)[1]]=1
    p=spsolve(L+diags(pins),D@drive)
    u=drive-D.T@p
    assert max(abs(D@u))<1e-10
    yy=y[wet]
    crossing=(yy[a]<0)&(yy[b]>0)
    left_to_right=np.maximum(u,0); reverse=np.maximum(-u,0)
    outgoing=np.bincount(a,weights=left_to_right,minlength=len(p))+np.bincount(b,weights=reverse,minlength=len(p))
    steps=int(np.ceil(12*outgoing.max()/(.8*h)))
    c=(yy<0).astype(float); initial=c.sum()
    for _ in range(steps):
        flux=left_to_right*c[a]-reverse*c[b]
        c-=12/(steps*h)*(D@flux)
    assert abs(c.sum()-initial)<1e-8 and c.min()>-1e-10 and c.max()<1+1e-10
    # Signed circulation through each loop's OUTER straight, far from gate.
    cuts=(x[wet][a]<0)&(x[wet][b]>0)
    return [h,opening,direction,h*np.maximum(u[crossing],0).sum(),100*c[yy>0].sum()/initial,
            abs(h*u[cuts&(yy[a]>1.4)].sum()),abs(h*u[cuts&(yy[a]<-1.4)].sum())]

if __name__=="__main__":
    with open("results.csv","w",newline="") as file:
        w=csv.writer(file); w.writerow(["grid","opening_width","relative_rotation","one_way_gate_flux","dye_in_upper_percent_t12","upper_outer_flux","lower_outer_flux"])
        for h in [.05,.025,.0125]:
            for direction in [1,-1]:
                for width in [0,.5,1]:
                    row=simulate(h,width,direction); w.writerow(row); print(row)
