"""Passive NOAA NCEP/NCAR Reanalysis 1 wind replay for the Traveler.

Run: python Traveler-Wind-Replay.py --download
Requires NumPy and SciPy. The public data are cached in traveler-data/.
Prints CSV to stdout. Defaults to four seasonal starts in 2024.
Pressure surfaces are proxies for float levels, not fixed geometric altitudes.
The approach metric uses a generic circle around the start and models float
position only. It does not model descent, authorization, or landing.
"""

import argparse
import calendar
import csv
from datetime import date
from pathlib import Path
import re
import struct
import sys
import time
import urllib.error
import urllib.request

import numpy as np
from scipy.interpolate import RegularGridInterpolator

EARTH_RADIUS_M = 6_371_000
START_LAT = 42.0
START_LON = -71.0
APPROACH_KM = 500.0
LEVELS = (70, 50, 30)
BASE_URL = "https://psl.noaa.gov/thredds/dodsC/Datasets/ncep.reanalysis/pressure"


def read_wind(directory, component, year, download):
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"{component}.{year}.dods"
    if not path.exists() and download:
        final_index = 4 * (365 + calendar.isleap(year)) - 1
        query = f"{component}[0:1:{final_index}][12:1:14][0:2:72][0:2:142]"
        url = f"{BASE_URL}/{component}.{year}.nc.dods?{query}"
        for attempt in range(3):
            try:
                with urllib.request.urlopen(url, timeout=45) as response:
                    payload = response.read()
                path.write_bytes(payload)
                break
            except (OSError, urllib.error.URLError):
                if attempt == 2:
                    raise
                time.sleep(4)
    header, binary = path.read_bytes().split(b"\nData:\n", 1)
    shape_match = re.search(
        rb"Float32 " + component.encode()
        + rb"\[time = (\d+)\]\[level = (\d+)\]\[lat = (\d+)\]\[lon = (\d+)\]", header
    )
    if shape_match is None:
        raise ValueError(f"Unexpected NOAA header for {path}")
    shape = tuple(int(value) for value in shape_match.groups())
    offset = 0

    def array(count, dtype):
        nonlocal offset
        sizes = struct.unpack_from(">II", binary, offset)
        if sizes != (count, count):
            raise ValueError(f"Unexpected DAP array length for {path}: {sizes}")
        offset += 8
        values = np.frombuffer(binary, dtype=dtype, count=count, offset=offset)
        offset += values.nbytes
        return values.astype(float)

    winds = array(int(np.prod(shape)), ">f4").reshape(shape)
    hours = array(shape[0], ">f8")
    levels = array(shape[1], ">f4")
    latitude = array(shape[2], ">f4")
    longitude = array(shape[3], ">f4")
    if offset != len(binary) or not np.array_equal(levels, LEVELS):
        raise ValueError(f"Unexpected pressure grid or trailing data for {path}")
    expected_hours = 24 * (date(year, 1, 1) - date(1800, 1, 1)).days
    if not np.array_equal(hours, expected_hours + 6 * np.arange(4 * (365 + calendar.isleap(year)))):
        raise ValueError(f"Unexpected year or incomplete six-hour grid for {path}")
    if not np.array_equal(latitude, np.arange(90, -91, -5)) or not np.array_equal(longitude, np.arange(0, 360, 5)):
        raise ValueError(f"Unexpected geographic grid for {path}")
    if not np.all(np.isfinite(winds)) or np.max(np.abs(winds)) > 250:
        raise ValueError(f"Missing or out-of-range wind values in {path}")
    return hours - expected_hours, winds


def great_circle_km(latitude, longitude):
    latitude1, latitude2 = np.radians([START_LAT, latitude])
    delta_lon = np.radians((longitude - START_LON + 180) % 360 - 180)
    a = np.sin((latitude2 - latitude1) / 2) ** 2
    a += np.cos(latitude1) * np.cos(latitude2) * np.sin(delta_lon / 2) ** 2
    return float(2 * EARTH_RADIUS_M / 1000 * np.arcsin(np.sqrt(np.clip(a, 0, 1))))


def score(track, radius_km=APPROACH_KM):
    """Report the first net 360-degree lap and the first sampled approach after it."""
    lap_day = approach_day = None
    closest_km = float("inf")
    for day, latitude, longitude in track:
        if lap_day is None and abs(longitude - START_LON) >= 360:
            lap_day = day
        if lap_day is not None:
            distance = great_circle_km(latitude, longitude)
            closest_km = min(closest_km, distance)
            if approach_day is None and distance <= radius_km:
                approach_day = day
    return lap_day, approach_day, closest_km if lap_day is not None else None


def replay(wind, start_hour, step_hours):
    """Integrate horizontal passive drift with RK4 and periodic wind longitude."""
    hour = start_hour
    position = np.array([START_LAT, START_LON])
    track = [(0.0, *position)]
    seconds_per_step = 3600 * step_hours

    def derivative(time_hour, point):
        latitude, longitude = point
        if abs(latitude) >= 85:
            raise ArithmeticError("Polar limit reached")
        east, north = wind((time_hour, latitude, longitude % 360))
        return np.degrees([north, east / np.cos(np.radians(latitude))]) / EARTH_RADIUS_M

    for step in range(1, round(90 * 24 / step_hours) + 1):
        try:
            k1 = derivative(hour, position)
            k2 = derivative(hour + step_hours / 2, position + seconds_per_step * k1 / 2)
            k3 = derivative(hour + step_hours / 2, position + seconds_per_step * k2 / 2)
            k4 = derivative(hour + step_hours, position + seconds_per_step * k3)
        except ArithmeticError:
            return track, "polar limit"
        position += seconds_per_step / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        hour = start_hour + step * step_hours
        track.append((step * step_hours / 24, *position))
    return track, "90 days"


def self_test():
    assert score([(0, START_LAT, START_LON), (25, START_LAT, START_LON + 360)])[:2] == (25, 25)
    assert score([(65, START_LAT, START_LON + 359), (75, 10, START_LON + 360)])[:2] == (75, None)
    assert score([(0, START_LAT, START_LON), (75, START_LAT, START_LON + 359)]) == (None, None, None)
    assert score([(25, START_LAT, START_LON - 360)])[:2] == (25, 25)
    track, status = replay(lambda _: (20, 0), 0, 1)
    expected = 2 * np.pi * EARTH_RADIUS_M * np.cos(np.radians(START_LAT)) / (20 * 86400)
    assert status == "90 days" and abs(score(track)[0] - expected) <= 1 / 24


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path("traveler-data"))
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--years", nargs="+", type=int, default=[2024])
    parser.add_argument("--step-hours", type=float, default=1, choices=(1, 0.5, 0.25, 0.125))
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    self_test()
    if args.self_test:
        print("Synthetic regression checks passed.")
        return

    writer = csv.writer(sys.stdout)
    writer.writerow(["start", "pressure_hpa", "lap_day", "approach_day", "closest_post_lap_km", "end"])
    for year in args.years:
        hours, east = read_wind(args.data_dir, "uwnd", year, args.download)
        north_hours, north = read_wind(args.data_dir, "vwnd", year, args.download)
        if not np.array_equal(hours, north_hours):
            raise ValueError("Wind component time grids differ")
        for index, level in enumerate(LEVELS):
            values = np.stack([east[:, index, ::-1], north[:, index, ::-1]], axis=-1)
            periodic = np.concatenate([values, values[:, :, :1]], axis=2)
            wind = RegularGridInterpolator(
                (hours, np.arange(-90, 91, 5), np.arange(0, 361, 5)), periodic, bounds_error=True
            )
            for month in (1, 4, 7, 10):
                start = date(year, month, 1)
                start_hour = (start - date(year, 1, 1)).days * 24
                track, end = replay(wind, start_hour, args.step_hours)
                lap, approach, closest = score(track)
                rounded = [round(value, 2) if value is not None else "" for value in (lap, approach, closest)]
                writer.writerow([start.isoformat(), level, *rounded, end])


if __name__ == "__main__":
    main()
