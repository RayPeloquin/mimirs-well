# Traveler historical wind replay

This is a passive drift benchmark for the civilian Traveler concept. It uses
2024 NOAA NCEP/NCAR Reanalysis 1 six-hourly winds, sampled on a 5° grid,
at fixed 70, 50 and 30 hPa pressure surfaces. These surfaces vary in geometric
altitude. No propulsion, altitude changes, or forecast-based decisions are used.

Each batch starts on Jan 1, Apr 1, Jul 1 and Oct 1 at 42° N, 71° W,
uses time and spatial interpolation, and runs for up to 90 days. The
integrator stops above 85° absolute latitude. Those stops are inconclusive
if the trajectory had yet to complete a lap. A lap is cumulative net
longitude change of at least 360° in either direction. Approach scoring
begins at the first sampled lap crossing and ends at day 90. An approach
means the float trajectory passed within 500 km of the starting point.
It supplies no evidence about a descent, a landing, or aviation authorization.

Run with NumPy and SciPy installed:

```sh
python Traveler-Wind-Replay.py --self-test
python Traveler-Wind-Replay.py --download --step-hours 0.125
```

The CSV columns show the UTC launch date, pressure level, days elapsed
at lap and approach, nearest post-lap distance in km, and stop reason.
Blank event cells indicate an event was never observed during the run.
The wind data are downloaded separately and are not bundled here.

Source: https://psl.noaa.gov/data/gridded/data.ncep.reanalysis.html
